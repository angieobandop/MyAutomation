package test.java.co.com.jira.utils;

public class DataSaver {

    String issueKey, idCom;

    public String getIssueKey() {
        return issueKey;
    }

    public void setIssueKey(String issueKey) {
        this.issueKey = issueKey;
    }

    public void setIdCom(String idCom) {
        this.idCom = idCom;
    }

    public String getIdCom() {
        return idCom;
    }


}

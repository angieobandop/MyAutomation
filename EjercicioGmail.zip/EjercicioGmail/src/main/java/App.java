import java.util.concurrent.TimeUnit;

import javax.swing.JOptionPane;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

public class App { 
	
	
	public static WebDriver driver; 
	public static void main(String[] args) {
		
		System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
		System.out.println("WebDriver Inicializado");
		driver = new ChromeDriver();
		
		
		
		driver.manage().window().maximize(); //Maximiza la pantalla del navegador
        driver.get("https://www.google.com.co"); // Establece  la pagina en la que inica el navegador
        driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); //Tiempo de espera.
        
        //WebDriverWait wait = new WebDriverWait(driver, 20); // 
        
        
        WebElement search;
        search = driver.findElement(By.xpath("//input[@id='lst-ib']"));
        search.sendKeys("gmail\n");
		
        
        WebElement wiki;
        wiki = driver.findElement(By.xpath("//a[@href=\"https://www.google.com/gmail/\"]"));
        wiki.click();
		
		
		
		WebElement searchemail;
        searchemail = driver.findElement(By.xpath("//input[@id='identifierId']"));
        searchemail.sendKeys("angelamariagrc04@gmail.com\n");
        //WebDriverWait waitt = new WebDriverWait(driver, 2);
        
        
        WebElement searchpass;
        searchpass = driver.findElement(By.xpath("//input[@name='password']"));
        searchpass.sendKeys("A99012306756\n");
        
        
        WebElement redactar;
        redactar = driver.findElement(By.xpath("//div[@gh='cm']"));
        redactar.click();
        
        WebElement email;
       email = driver.findElement(By.xpath("//textarea[@name='to']"));
        email.sendKeys("angelamariagrc04@gmail.com\n");
        
        WebElement asunto;
        asunto = driver.findElement(By.xpath("//input[@name='subjectbox']"));
         asunto.sendKeys("Prueba de envio de correo.\n");
         
         WebElement send;
         send = driver.findElement(By.xpath("//div[@id=':pd']"));
         send.click();
         
         
         try {
     		Thread.sleep(3000);
     		
     	}catch (InterruptedException e) {
    
     		e.printStackTrace();
     	
     	}
         
        WebElement enviados;
        enviados = driver.findElement(By.xpath("//div[@class='TN bzz aHS-bnu']"));
        enviados.click();
        
        
        WebElement getTe;
    	getTe = driver.findElement(By.xpath("//span[@class=\"bog\"]"));
    	System.out.println(getTe.getText());
    	
    	if (getTe.getText().equalsIgnoreCase("Prueba de envio de correo.")) {
    		JOptionPane.showMessageDialog(null, "El asunto es igual a Prueba de envio de correo.");
    	} else {
    		JOptionPane.showMessageDialog(null,"El asunto no es igual a Prueba de envio de correo.");
        
	}

	}
	
}
